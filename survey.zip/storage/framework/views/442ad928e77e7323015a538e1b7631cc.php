<?php $__env->startSection('content'); ?>
    <div class="row d-flex justify-content-center align-items-center" style="height: 100vh">
        <div class="col-md-4">
            <h4 class="text-center mb-4">Admin Login</h4>
            <?php if($errors->any()): ?>
                <div class="alert alert-danger pt-2 pb-0">
                    <ol>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <strong>
                                <?php if(count($errors->all()) == 1): ?>
                                    <?php echo e($error); ?>

                                <?php else: ?>
                                    <li>
                                        <?php echo e($error); ?>

                                    </li>
                                <?php endif; ?>
                            </strong>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ol>
                </div>
            <?php endif; ?>
            <form class="mt-3" method="POST" action="<?php echo e(route('login.post')); ?>">
                <?php echo csrf_field(); ?>
                <!-- Email input -->
                <div data-mdb-input-init class="form-outline mb-4">
                    <input id="email" type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                        name="email" value="<?php echo e(old('email')); ?>" autofocus>
                    <label class="form-label" for="form2Example1">Email address</label>
                </div>

                <!-- Password input -->
                <div data-mdb-input-init class="form-outline mb-4">
                    <input type="password" name="password" id="form2Example2" class="form-control" />
                    <label class="form-label" for="form2Example2">Password</label>
                </div>


                <!-- Submit button -->
                <button type="submit" class="btn btn-primary btn-block mb-4">
                    Sign in
                </button>

            </form>
        </div>
        </>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/authlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\survey\resources\views/auth/auth.blade.php ENDPATH**/ ?>