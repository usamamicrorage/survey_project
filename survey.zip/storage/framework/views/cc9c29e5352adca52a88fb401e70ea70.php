<?php $__env->startSection('content'); ?>
    <div class="row mt-3">
        <div class="col-md-4">
            <div class="card">
                <div class="card-header">
                    <h3 class="text-center pt-4"> <?php echo e($mode == 'edit' ? 'Update' : 'Add'); ?> Profession</h3>
                </div>
                <div class="card-body">
                    <form method="post"
                        action="<?php echo e($mode == 'edit' ? route('profession.update', $profession) : route('profession.store')); ?>">
                        <?php if($mode == 'edit'): ?>
                            <?php echo method_field('PUT'); ?>
                        <?php endif; ?>
                        <?php echo csrf_field(); ?>
                        <div data-mdb-input-init class="form-outline mb-4">
                            <input id="form2Example1" type="text" value="<?php echo e($mode == 'edit' ? $profession->title : ''); ?>"
                                class="form-control" name="title">
                            <label class="form-label" for="form2Example1">Enter Title</label>
                        </div>

                        <button type="submit"
                            class="btn btn-<?php echo e($mode == 'edit' ? 'warning' : 'primary'); ?> bt-sm btn-block mb-4"><?php echo e($mode == 'edit' ? 'Update' : 'Save'); ?>

                            Profession</button>
                    </form>
                </div>
            </div>
        </div>
        <div class="col-md-8">
            <div class="card">
                <div class="card-head pt-3 px-3">
                    <h3>Professions List</h3>
                </div>
                <hr>
                <div class="card-body">
                    <table class="table table-sm table-bordered table-striped">
                        <thead>
                            <tr>
                                <th class="text-end">Sr#</th>
                                <th>Title</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if(count($professions) > 0): ?>
                                <?php
                                    $c = 1;
                                ?>
                                <?php $__currentLoopData = $professions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $profession): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td class="text-end"><?php echo e($c); ?></td>
                                        <td> <?php echo e($profession->title); ?> </td>
                                        <td>
                                            <a href="<?php echo e(route('profession.edit', $profession)); ?>"
                                                class="btn btn-primary btn-sm">Edit</a>
                                            <form action="<?php echo e(route('profession.destroy', $profession)); ?>" method="POST"
                                                onsubmit="return confirm('Are you sure you want to delete this?');"
                                                style="display:inline;">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit" class="btn btn-danger btn-sm">Delete</button>
                                            </form>
                                        </td>
                                    </tr>
                                    <?php $c++ ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="3" class="text-center">No Professions, Create One..</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                    <div class="pagination-wrapper mt-4">
                        <?php echo e($professions->links('vendor.pagination.bootstrap-5')); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\survey\resources\views/admin/profession/index.blade.php ENDPATH**/ ?>