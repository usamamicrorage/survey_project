<?php $__env->startSection('content'); ?>
    <div class="container">
        <form action="<?php echo e(route('survey_reponse.submit', $survey->id)); ?>" method="POST">
            <div class="row">
                <div class="col-md-10 offset-md-1">
                    <div class="card">
                        <div class="card-header">
                            <div class="row">
                                <div class="col-md-12">
                                    <h1><?php echo e($survey->title); ?></h1>
                                    <p><?php echo e($survey->description); ?></p>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-4 offset-md-8">
                                    <div class="form-group">
                                        <label for="profession">Profession:</label>
                                        <select name="profession_id" class="form-select form-control" required>
                                            <option value="">Select your profession</option>
                                            <?php $__currentLoopData = $professions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $profession): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($profession->id); ?>"><?php echo e($profession->title); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="card-body">
                            
                            <?php if(session('success')): ?>
                                <div class="alert alert-success">
                                    <?php echo e(session('success')); ?>

                                </div>
                            <?php endif; ?>
                            <?php echo csrf_field(); ?>
                            <?php $__currentLoopData = $survey->questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="form-group">
                                    <p class="m-0 font-bold"><?php echo e($index + 1); ?>. <?php echo e($question->title); ?></p>

                                    <div class="d-flex ">
                                        <div class="form-check form-check-inline">
                                            <input id="question_<?php echo e($question->id); ?>_agree" class="form-check-input"
                                                type="radio" name="responses[<?php echo e($question->id); ?>]" value="agree"
                                                required>
                                            <label for="question_<?php echo e($question->id); ?>_agree"
                                                class="form-check-label">Agree</label>
                                        </div>
                                        <div class="form-check form-check-inline">
                                            <input id="question_<?php echo e($question->id); ?>_disagree" class="form-check-input"
                                                type="radio" name="responses[<?php echo e($question->id); ?>]" value="disagree"
                                                required>
                                            <label for="question_<?php echo e($question->id); ?>_disagree"
                                                class="form-check-label">Disagree</label>
                                        </div>
                                        <div class="form-check form-check-inline">
                                            <input id="question_<?php echo e($question->id); ?>_not_applicble" class="form-check-input"
                                                type="radio" name="responses[<?php echo e($question->id); ?>]" value="not_applicable"
                                                required>
                                            <label for="question_<?php echo e($question->id); ?>_not_applicble"
                                                class="form-check-label">Not Applicable</label>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <hr>
                            <div class="text-end">
                                <button type="submit" class="btn btn-primary">Submit Survey</button>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.authlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\survey\resources\views/index.blade.php ENDPATH**/ ?>