<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <div class="inline-block mx-4 my-3 text-end">
                        <a href="<?php echo e(route('questions.create', $survey_id)); ?>" class="btn btn-primary">Add More Questions</a>
                    </div>
                </div>
                <div class="card-body">
                    <table class="table table-sm table-bordered table-striped">

                        <thead>
                            <tr>
                                <th>Sr#</th>
                                <th>Question</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                                $c = 1;
                            ?>
                            <?php $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($c); ?></td>
                                    <td><?php echo e($question->title); ?></td>
                                    <td>

                                    </td>
                                </tr>
                                <?php
                                $c++;
                                ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <div class="pagination-wrapper mt-4">
                        <?php echo e($questions->links('vendor.pagination.bootstrap-5')); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\survey\resources\views/admin/questions/show.blade.php ENDPATH**/ ?>