<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta http-equiv="x-ua-compatible" content="ie=edge" />
    <title><?php echo e($title); ?> - AI Survey </title>
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" />
    <!-- Google Fonts Roboto -->
    <link rel="stylesheet"
        href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700;900&display=swap" />
    <!-- MDB -->
    <link rel="stylesheet" href="<?php echo e(URL::asset('assets/css/mdb.min.css')); ?>" />
</head>

<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-light bg-body-tertiary">
        <!-- Container wrapper -->
        <div class="container-fluid">
            <a class="navbar-brand mt-2 mt-lg-0" href="<?php echo e(route('dashboard')); ?>">
                AI Survey
            </a>
            <!-- Toggle button -->
            <button data-mdb-collapse-init class="navbar-toggler" type="button"
                data-mdb-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false"
                aria-label="Toggle navigation">
                <i class="fas fa-bars"></i>
            </button>

            <!-- Collapsible wrapper -->
            <div class="collapse navbar-collapse justify-content-center" id="navbarSupportedContent">
                <!-- Centered Links -->
                <ul class="navbar-nav mb-2 mb-lg-0">
                    <li class="nav-item ">
                        <a class="nav-link <?php echo e(Route::is('dashboard') ? 'active' : ''); ?>"
                            href="<?php echo e(route('dashboard')); ?>">Dashboard</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php echo e(Route::is('profession.index') || Route::is('profession.edit') ? 'active' : ''); ?>"
                            href="<?php echo e(route('profession.index')); ?>">Professions</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php echo e(Route::is('survey.index') ? 'active' : ''); ?>"
                            href="<?php echo e(route('survey')); ?>">Surveys</a>
                    </li>
                </ul>
            </div>
            <!-- Collapsible wrapper -->
        </div>
        <!-- Container wrapper -->
    </nav>
    <!-- Navbar -->
    <!-- Start your project here-->
    <div class="container">
        <div class="row mt-2">
            <div class="col-md-6 offset-md-3">
                <?php if($errors->any()): ?>
                    <div class="alert alert-danger p-0">
                        <ol>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <strong>
                                    <?php if(count($errors->all()) == 1): ?>
                                        <?php echo e($error); ?>

                                    <?php else: ?>
                                        <li>
                                            <?php echo e($error); ?>

                                        </li>
                                    <?php endif; ?>
                                </strong>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ol>
                    </div>
                <?php endif; ?>
                <?php if(session()->has('message')): ?>
                    <div class="alert alert-success">
                        <?php echo e(session()->get('message')); ?>

                    </div>
                <?php endif; ?>
            </div>
        </div>
        <?php echo $__env->yieldContent('content'); ?>
    </div>
    <!-- End your project here-->

    <!-- MDB -->
    <script type="text/javascript" src="<?php echo e(URL::asset('assets/js/mdb.umd.min.js')); ?>"></script>
    <!-- Custom scripts -->
    <script type="text/javascript"></script>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\survey\resources\views/layouts/app.blade.php ENDPATH**/ ?>