<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <div class="inline-block mx-4 my-3 text-end">
                        <a href="<?php echo e(route('survey.create')); ?>" class="btn btn-primary">Create New Survey</a>
                    </div>
                </div>
                <div class="card-body">
                    <table class="table table-sm table-striped table-bordered">
                        <thead>
                            <tr>
                                <th>Sr#</th>
                                <th>Title</th>
                                <th>Description</th>
                                <th>Total Questions</th>
                                <th>Status</th>
                                <th>Total Responses</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                                $c = 1;
                            ?>
                            <?php if(count($surveys) > 0): ?>
                                <?php $__currentLoopData = $surveys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $survey): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($c); ?></td>
                                        <td><?php echo e($survey->title); ?></td>
                                        <td><?php echo e(Str::limit($survey->description, 150)); ?></td>
                                        <td>
                                            <span
                                                class="mx-2 badge bg-<?php echo e($survey->questions_count == 0 ? 'danger' : 'success'); ?>">
                                                <?php echo e($survey->questions_count); ?>

                                            </span>
                                            <?php if($survey->questions_count == 0): ?>
                                                <a class="btn btn-dark btn-sm"
                                                    href="<?php echo e(route('questions.create', $survey->id)); ?>">Add</a>
                                            <?php endif; ?>
                                            <?php if($survey->questions_count > 0): ?>
                                                <a class="btn btn-info btn-sm"
                                                    href="<?php echo e(route('questions.show', $survey->id)); ?>">View</a>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <span class="badge bg-<?php echo e($survey->status == 1 ? 'success' : 'danger'); ?>">
                                                <?php echo e($survey->status == 1 ? 'Active' : 'InActive'); ?>

                                            </span>
                                        </td>
                                        <td>
                                            <span
                                                class="badge bg-<?php echo e($survey->totalResponses() == 0 ? 'danger' : 'success'); ?>">
                                                <?php echo e($survey->totalResponses()); ?>

                                            </span>
                                            <?php if($survey->totalResponses() > 0): ?>
                                                <a class="btn btn-dark btn-sm" href="javascript:void(0)">Analysis</a>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <a href="<?php echo e(route('survey.public.link', $survey->id)); ?>"
                                                class="btn btn-secondary btn-sm" target="_blank">Link</a>

                                        </td>
                                    </tr>
                                    <?php
                                        $c++;
                                    ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="7" class="text-center">No Survey Exists! Create One..</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                    <div class="pagination-wrapper mt-4">
                        <?php echo e($surveys->links('vendor.pagination.bootstrap-5')); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\survey\resources\views/admin/survey/index.blade.php ENDPATH**/ ?>